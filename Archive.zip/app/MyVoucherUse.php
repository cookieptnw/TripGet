<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MyVoucherUse extends Model
{
    //
}
