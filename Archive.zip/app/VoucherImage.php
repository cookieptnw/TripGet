<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VoucherImage extends Model
{
    //
}
