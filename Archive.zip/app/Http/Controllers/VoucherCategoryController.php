<?php

namespace App\Http\Controllers;

use App\VoucherCategory;
use Illuminate\Http\Request;

class VoucherCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\VoucherCategory  $voucherCategory
     * @return \Illuminate\Http\Response
     */
    public function show(VoucherCategory $voucherCategory)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\VoucherCategory  $voucherCategory
     * @return \Illuminate\Http\Response
     */
    public function edit(VoucherCategory $voucherCategory)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\VoucherCategory  $voucherCategory
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, VoucherCategory $voucherCategory)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\VoucherCategory  $voucherCategory
     * @return \Illuminate\Http\Response
     */
    public function destroy(VoucherCategory $voucherCategory)
    {
        //
    }
}
