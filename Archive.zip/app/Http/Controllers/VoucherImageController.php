<?php

namespace App\Http\Controllers;

use App\VoucherImage;
use Illuminate\Http\Request;

class VoucherImageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\VoucherImage  $voucherImage
     * @return \Illuminate\Http\Response
     */
    public function show(VoucherImage $voucherImage)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\VoucherImage  $voucherImage
     * @return \Illuminate\Http\Response
     */
    public function edit(VoucherImage $voucherImage)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\VoucherImage  $voucherImage
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, VoucherImage $voucherImage)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\VoucherImage  $voucherImage
     * @return \Illuminate\Http\Response
     */
    public function destroy(VoucherImage $voucherImage)
    {
        //
    }
}
