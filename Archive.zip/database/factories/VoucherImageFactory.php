<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\VoucherImage;
use Faker\Generator as Faker;

$factory->define(VoucherImage::class, function (Faker $faker) {
    return [
        //
    ];
});
