<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\MyVoucherUse;
use Faker\Generator as Faker;

$factory->define(MyVoucherUse::class, function (Faker $faker) {
    return [
        //
    ];
});
