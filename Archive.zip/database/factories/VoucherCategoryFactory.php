<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\VoucherCategory;
use Faker\Generator as Faker;

$factory->define(VoucherCategory::class, function (Faker $faker) {
    return [
        //
    ];
});
