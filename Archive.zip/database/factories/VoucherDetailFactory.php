<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\VoucherDetail;
use Faker\Generator as Faker;

$factory->define(VoucherDetail::class, function (Faker $faker) {
    return [
        //
    ];
});
