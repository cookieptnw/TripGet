<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\MyVoucher;
use Faker\Generator as Faker;

$factory->define(MyVoucher::class, function (Faker $faker) {
    return [
        //
    ];
});
