<template>
  <div class="footer">
    <div class="text-white text-center">
      <h6>© copyright 2020 www.tripget.com</h6>
    </div>
  </div>
</template>

<script>
export default {
  name: "Footer",
};
</script>

<style>
.footer {
  background-color: #195dfc;
}
.footer h6 {
  font-weight: 400;
  font-size: 18px;
  text-transform: uppercase;
}
</style>