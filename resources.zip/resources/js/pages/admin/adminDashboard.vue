<template>
  <div class="p-4">
    <card> admin Dashboard </card>
  </div>
</template>

<script>
export default {};
</script>

<style></style>
